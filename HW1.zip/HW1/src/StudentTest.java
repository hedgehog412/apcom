
public class StudentTest {
	public static void main (String[] args)
	{
		Student[] apcs=new Student [15];
		
		apcs[0]=new Student();
		apcs[1]=new Student();
		apcs[2]=new Student();
		apcs[3]=new Student();
		apcs[4]=new Student();
		apcs[5]=new Student();
		apcs[6]=new Student();
		apcs[7]=new Student();
		apcs[8]=new Student();
		apcs[9]=new Student();
		apcs[10]=new Student();
		apcs[11]=new Student();
		apcs[12]=new Student();
		apcs[13]=new Student();
		apcs[14]=new Student();
		
		apcs[0].setName("KwonHaeChan");
		apcs[1].setName("ParkSangYoon");
		apcs[2].setName("ShinJaeRyong");
		apcs[3].setName("SeoJaeDuck");
		apcs[4].setName("LeeSeungHo");
		apcs[5].setName("JeonJiHyun");
		apcs[6].setName("KimJaeHong");
		apcs[7].setName("UmTaeJun");
		apcs[8].setName("AhnJooUn");
		apcs[9].setName("ShinJoongHyuk");
		apcs[10].setName("LeeSiHyun");
		apcs[11].setName("HongJiMin");
		apcs[12].setName("LeeSeungHyun");
		apcs[13].setName("KimTaeJun");
		apcs[14].setName("JoHoYeon");
		
		apcs[0].setAge(18);
		apcs[1].setAge(18);
		apcs[2].setAge(18);
		apcs[3].setAge(18);
		apcs[4].setAge(17);
		apcs[5].setAge(17);
		apcs[6].setAge(18);
		apcs[7].setAge(18);
		apcs[8].setAge(17);
		apcs[9].setAge(18);
		apcs[10].setAge(18);
		apcs[11].setAge(18);
		apcs[12].setAge(18);
		apcs[13].setAge(17);
		apcs[14].setAge(18);
		
		apcs[0].setHeight(180.5);
		apcs[1].setHeight(180.5);
		apcs[2].setHeight(180.5);
		apcs[3].setHeight(180.5);
		apcs[4].setHeight(180.5);
		apcs[5].setHeight(170.5);
		apcs[6].setHeight(180.5);
		apcs[7].setHeight(180.5);
		apcs[8].setHeight(180.5);
		apcs[9].setHeight(180.5);
		apcs[10].setHeight(170.5);
		apcs[11].setHeight(170.5);
		apcs[12].setHeight(180.5);
		apcs[13].setHeight(180.5);
		apcs[14].setHeight(180.5);
		
		System.out.println(apcs[0].getName()+" "+apcs[0].getAge()+" "+apcs[0].getHeight());
		System.out.println(apcs[1].getName()+" "+apcs[1].getAge()+" "+apcs[1].getHeight());
		System.out.println(apcs[2].getName()+" "+apcs[2].getAge()+" "+apcs[2].getHeight());
		System.out.println(apcs[3].getName()+" "+apcs[3].getAge()+" "+apcs[3].getHeight());
		System.out.println(apcs[4].getName()+" "+apcs[4].getAge()+" "+apcs[4].getHeight());
		System.out.println(apcs[5].getName()+" "+apcs[5].getAge()+" "+apcs[5].getHeight());
		System.out.println(apcs[6].getName()+" "+apcs[6].getAge()+" "+apcs[6].getHeight());
		System.out.println(apcs[7].getName()+" "+apcs[7].getAge()+" "+apcs[7].getHeight());
		System.out.println(apcs[8].getName()+" "+apcs[8].getAge()+" "+apcs[8].getHeight());
		System.out.println(apcs[9].getName()+" "+apcs[9].getAge()+" "+apcs[9].getHeight());
		System.out.println(apcs[10].getName()+" "+apcs[10].getAge()+" "+apcs[10].getHeight());
		System.out.println(apcs[11].getName()+" "+apcs[11].getAge()+" "+apcs[11].getHeight());
		System.out.println(apcs[12].getName()+" "+apcs[12].getAge()+" "+apcs[12].getHeight());
		System.out.println(apcs[13].getName()+" "+apcs[13].getAge()+" "+apcs[13].getHeight());
		System.out.println(apcs[14].getName()+" "+apcs[14].getAge()+" "+apcs[14].getHeight());
	}
}
